from setuptools import setup, find_packages

setup(
    name="mi_paquete_clientes",
    version="0.1",
    packages=find_packages(),
    install_requires=[],
    description="Paquete para gestionar clientes en una página de compras",
    author="Yanel Yapura",
    author_email="yanelyapura@gmail.com",
)
